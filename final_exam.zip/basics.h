﻿#include <iostream>
int sum_numbers(int num1, int num2);

//write function prototype for multiply_numbers with two integer parameters
int multiply_numbers(int num1, int num2);

void pass_by_val_by_ref(int val, int& ref);

void const_pass_by_val_by_ref(int val, const int& ref);

void pass_by_pointer(int* ptr);

void initialize_vector_of_ints();

void initialize_vector_of_strings();

#ifndef MY_CLASS_H
#define MY_CLASS_H

class DynamicPtr
{
public:
	DynamicPtr();
	~DynamicPtr();
private:
	int* ptr_num;
};

class MyClass
{
public:
	MyClass();
	MyClass(MyClass& my_class);//copy constructor
	void set_ptr_num(int val);
	MyClass& operator=(MyClass other);//overloaded =
	~MyClass();//destructor

private:
	int num{ 5 };
	int* ptr_num = new int(10);
};

class Receipt
{
public:
	Receipt();
	Receipt(double a, double tax = 0.075) : amount(a), tax_rate(tax) {};
	virtual void display();
	friend std::istream& operator >>(std::istream& in, Receipt& r);
	friend std::ostream& operator <<(std::ostream& out, Receipt& r);
	friend void overwrite_tax(Receipt& r, double new_tax_rate);
	friend Receipt operator+(const Receipt& first, const Receipt& second);
protected:
	virtual double calculate_bill_total();
	double amount;
	double tax_rate;
	double tip_amount{ 0.10 * amount};
	double tax_amount{ tax_rate*amount };
};

class TaxExemptReceipt : public Receipt
{
public:
	TaxExemptReceipt();
	TaxExemptReceipt(double a) : Receipt(a, 0) {};
	void display();
protected:
	double calculate_bill_total();

};

class Test
{
public:
	Test();
	~Test();
	void execute();
private:
	Receipt* receipt_ptr;

};

class Test3
{
public:
	Test3();
	~Test3();
	void execute();
private:
	Receipt* receipt_ptr;

};

class Test4
{
public:
	void execute();
private:
	std::unique_ptr<Receipt> receipt_ptr[5];
};

class Test8
{
public:
	void execute();
private:
	std::unique_ptr<Receipt> receipt_ptr;
	std::unique_ptr<TaxExemptReceipt> no_tax_ptr;
};

class Shape
{
public:
	virtual void draw() = 0;
};

class Circle : public Shape
{
public:
	void draw() { std::cout << "You drew a Circle\n"; };
};

class Line : public Shape
{
public:
	void draw() { std::cout << "You drew a Line\n"; };
};


#endif //!MY_CLASS_H