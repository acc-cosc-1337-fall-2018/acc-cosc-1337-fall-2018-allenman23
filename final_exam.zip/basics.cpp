#include "basics.h"
#include<iomanip>

int sum_numbers(int num1, int num2)
{
	return num1 + num2;
}

//write code for multiply_numbers function here
int multiply_numbers(int num1, int num2)
{
	return num1 * num2;
}

void pass_by_val_by_ref(int val, int& ref)
{
	val = 99;
	ref = 99;
}

void const_pass_by_val_by_ref(int val, const int & ref)
{
	val = 99;
	//ref = 99; ref can't be modified
}

void pass_by_pointer(int * ptr)
{
	//ptr: we're using the address
	*ptr = 99;//*ptr: get the fvalue of the address pointed to
}

void initialize_vector_of_ints()
{
}

void initialize_vector_of_strings()
{
}

MyClass::MyClass()
{
	std::cout << "Constructor...\n";
}

MyClass::MyClass(MyClass & my_class)
{
	ptr_num = new int(*my_class.ptr_num);
}

void MyClass::set_ptr_num(int val)
{
	*ptr_num = val;
}

MyClass & MyClass::operator=(MyClass other)
{
	delete other.ptr_num;
	ptr_num = new int(*other.ptr_num);
	return *this;
}

MyClass::~MyClass()
{
	std::cout << "Num: " <<num << "\nPtr num: " << *ptr_num << "\nAddress at Ptr num: " << ptr_num << "\nDestructor...\n";
}

DynamicPtr::DynamicPtr()
{
	std::cout << "DynamicPtr Constructor runs\n";
}

DynamicPtr::~DynamicPtr()
{
	std::cout << "DynamicPtr Destructor runs\n";
}

Receipt::Receipt()
{
	tax_rate = 0.075;
}

void Receipt::display()
{
	std::cout << "Taxable:\n\n";
	std::cout << std::fixed << std::setprecision(2);
	std::cout << " Bill Amount: " <<  amount << "\n";
	std::cout << "  Tip Amount: " << tip_amount << "\n";
	std::cout << "  Tax Amount: " << tax_amount << "\n";
	std::cout << "Total Amount: " << calculate_bill_total() << "\n\n";
}

double Receipt::calculate_bill_total()
{
	return amount + tax_amount + tip_amount;
}

Test::Test()
{
	receipt_ptr = new Receipt();
}

Test::~Test()
{
	delete receipt_ptr;
	receipt_ptr = nullptr;
}

void Test::execute()
{
	std::cin >> *receipt_ptr;
	std::cout << *receipt_ptr;
	overwrite_tax(*receipt_ptr, 0.10);
	std::cout << *receipt_ptr;
}

std::istream& operator >>(std::istream& in, Receipt& r)
{
	std::cout << "Input Amount: ";
	std::cin >> r.amount;
	r.tax_amount = r.amount * r.tax_rate;
	r.tip_amount = r.amount * 0.10;
	return in;
}

std::ostream& operator <<(std::ostream& out, Receipt& r)
{
	r.display();
	return out;
}

void overwrite_tax(Receipt & r, double new_tax_rate)
{
	r = Receipt(r.amount, new_tax_rate);
}

Receipt operator+(const Receipt & first, const Receipt & second)
{
	Receipt third;
	third.amount = first.amount + second.amount;
	third.tax_amount = first.tax_amount + second.tax_amount;
	third.tip_amount = first.tip_amount + second.tip_amount;
	return third;
}

Test3::Test3()
{
	receipt_ptr = new Receipt[5];
}

Test3::~Test3()
{
	delete[] receipt_ptr;
	receipt_ptr = nullptr;
}

void Test3::execute()
{
	for (int i = 0; i < 5; ++i)
		receipt_ptr[i] = Receipt((i + 1) * 10);
	for (int i = 0; i < 5; ++i)
		std::cout << receipt_ptr[i];
}

void Test4::execute()
{
	for (int i = 0; i < 5; ++i)
		receipt_ptr[i] = std::make_unique<Receipt>((i + 1) * 10);
	for (int i = 0; i < 5; ++i)
		std::cout << *receipt_ptr[i];
}

TaxExemptReceipt::TaxExemptReceipt()
{
	tax_rate = 0;
}

void TaxExemptReceipt::display()
{
	std::cout << "Tax Exempt:\n\n";
	std::cout << std::fixed << std::setprecision(2);
	std::cout << " Bill Amount: " << amount << "\n";
	std::cout << "  Tip Amount: " << tip_amount << "\n";
	std::cout << "  Tax Amount: " << tax_amount << "\n";
	std::cout << "Total Amount: " << calculate_bill_total() << "\n\n";
}

double TaxExemptReceipt::calculate_bill_total()
{
	return amount + tip_amount;
}

void Test8::execute()
{
	receipt_ptr = std::make_unique<Receipt>(10, 0.08);
	no_tax_ptr = std::make_unique<TaxExemptReceipt>(10);
	std::cout << *receipt_ptr;
	std::cout << *no_tax_ptr;
}
