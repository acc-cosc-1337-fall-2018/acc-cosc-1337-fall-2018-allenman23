﻿#include "basics.h"
#include<memory>
#include<vector>

using std::cout;

int main()
{
//	cout << sum_numbers(5, 5);
/*	int num = 10;
	pass_by_pointer(&num);
	cout << num;
*/

/*	MyClass c;
	MyClass a = c;
	a.set_ptr_num(1000);
*/
/*
	MyClass* ptr_class = new MyClass();
	ptr_class->set_ptr_num(50);
	delete ptr_class;
	ptr_class = nullptr;
*/

/*
	std::unique_ptr<MyClass> ptr_class = std::make_unique<MyClass>();
	ptr_class->set_ptr_num(50);
	MyClass ptr_class2 = *ptr_class;
	ptr_class2.set_ptr_num(100);
	return 0;
*/

/*
	DynamicPtr a;
	DynamicPtr *b = new DynamicPtr();
	std::unique_ptr<DynamicPtr> c = std::make_unique<DynamicPtr>();
	delete b;
*/

//	Receipt a(10);
//	a.display();

// Final Exam Review

/* 1 & 2
	Test a;
	Test* b = new Test();
	std::unique_ptr<Test> c = std::make_unique<Test>();
	a.execute();
	b->execute();
	c->execute();
	delete b;
	b = nullptr;
*/

/* 3
	Test3 d;
	d.execute();
*/

/* 4
	Test4 e;
	e.execute();
*/

/* 5
	Receipt r1(20);
	Receipt r2 = r1;
	cout << r1;
	cout << r2;

	This works because a new copy is made on the stack

*/

/* 6
	Test f;
	f.execute();
*/

/* 7
	Receipt rec1(15, 0.05);
	Receipt rec2(40, 0.05);
	Receipt rec3 = rec1 + rec2;
	std::cout << rec3;
*/

/* 8
	Test8 g;
	g.execute();
*/

/* 9
	std::vector<std::unique_ptr<Receipt>> receipts;
	receipts.push_back(std::make_unique<TaxExemptReceipt>(10));
	receipts.push_back(std::make_unique<Receipt>(10, .05));

	for (auto &r : receipts) {
		cout << *r;
	}
*/

// 10
	std::vector<std::unique_ptr<Shape>> shapes;
	shapes.push_back(std::make_unique<Circle>());
	shapes.push_back(std::make_unique<Line>());
	shapes.push_back(std::make_unique<Circle>());
	shapes.push_back(std::make_unique<Line>());
	for (auto& i : shapes)
		i->draw();
	return 0;
}
